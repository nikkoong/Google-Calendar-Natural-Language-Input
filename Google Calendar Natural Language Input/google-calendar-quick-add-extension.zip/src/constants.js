export const EN = "en"

export const LOCALES = {
  en: {label: "English", value: EN},
}